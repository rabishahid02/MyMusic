console.log("JS file is connected.");

const audio = document.getElementById('audio');
const playBtn = document.getElementById('play');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const progress = document.getElementById('progress');
const volumeSlider = document.getElementById('volume');
const muteBtn = document.getElementById('mute');

const songTitle = document.getElementById('song-title');
const artistName = document.getElementById('artist-name');
const playlist = document.getElementById('playlist');

let songs = [
  {src: 'song1.mp3', title: 'Summer Vibes', artist: 'DJ Chill'},
  {src: 'song2.mp3', title: 'Night Ride', artist: 'Synthwave'},
  {src: 'song3.mp3', title: 'Sunset Dreams', artist: 'Lo-Fi Beats'},
  {src: 'song4.mp3', title: 'Morning Light', artist: 'Acoustic Soul'}
];

let currentIndex = 0;
let isPlaying = false;

// Load a song by index
function loadSong(index) {
  currentIndex = index;
  audio.src = songs[index].src;
  audio.load(); // Important to reload audio source
  songTitle.textContent = songs[index].title;
  artistName.textContent = songs[index].artist;

  // Highlight active song in playlist
  Array.from(playlist.children).forEach((li, i) => {
    li.classList.toggle('active', i === index);
  });
}

// Play or pause toggle
function togglePlay() {
  if(isPlaying){
    audio.pause();
  } else {
    audio.play();
  }
}

playBtn.addEventListener('click', togglePlay);

// Update play button icon on play/pause
audio.addEventListener('play', () => {
  isPlaying = true;
  playBtn.textContent = '⏸'; // Pause icon
});

audio.addEventListener('pause', () => {
  isPlaying = false;
  playBtn.textContent = '▶'; // Play icon
});

// Update progress bar as song plays
audio.addEventListener('timeupdate', () => {
  if(audio.duration){
    progress.value = (audio.currentTime / audio.duration) * 100;
  }
});

// Seek song on progress bar change
progress.addEventListener('input', () => {
  if(audio.duration){
    audio.currentTime = (progress.value / 100) * audio.duration;
  }
});

// Play previous song
prevBtn.addEventListener('click', () => {
  currentIndex = (currentIndex - 1 + songs.length) % songs.length;
  loadSong(currentIndex);
  audio.play();
});

// Play next song
nextBtn.addEventListener('click', () => {
  currentIndex = (currentIndex + 1) % songs.length;
  loadSong(currentIndex);
  audio.play();
});

// Function to update volume slider background fill
function updateVolumeSliderBackground(value) {
  const percent = value * 100;
  volumeSlider.style.setProperty('--volume-percent', percent + '%');
}

// Initialize volume slider background on page load
updateVolumeSliderBackground(volumeSlider.value);

// Volume control event
volumeSlider.addEventListener('input', () => {
  audio.volume = volumeSlider.value;
  updateVolumeSliderBackground(volumeSlider.value);

  // If volume is 0, mute audio and update button style
  if (audio.volume === 0) {
    audio.muted = true;
    muteBtn.classList.add('muted');
  } else {
    audio.muted = false;
    muteBtn.classList.remove('muted');
  }
});

// Mute/unmute toggle event
muteBtn.addEventListener('click', () => {
  audio.muted = !audio.muted;

  if (audio.muted) {
    muteBtn.classList.add('muted');
    volumeSlider.value = 0;
    updateVolumeSliderBackground(0);
  } else {
    muteBtn.classList.remove('muted');
    // Restore volume slider to audio volume or default 1
    volumeSlider.value = audio.volume || 1;
    updateVolumeSliderBackground(volumeSlider.value);
  }
});

// Play song when user clicks playlist item
playlist.addEventListener('click', (e) => {
  if(e.target && e.target.tagName === 'LI'){
    let index = Array.from(playlist.children).indexOf(e.target);
    loadSong(index);
    audio.play();
  }
});

// Load first song on page load
loadSong(currentIndex);
